--
-- PostgreSQL database dump
--

\restrict fakDtu1XBfaBxq7cVQF5OXbnbbrzagaeBY31z0Le5emalcw2qnd1J2AjuF5gLVY

-- Dumped from database version 16.10 (Ubuntu 16.10-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.10 (Ubuntu 16.10-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: articles; Type: TABLE; Schema: public; Owner: theunitribe_admin
--

CREATE TABLE public.articles (
    id bigint NOT NULL,
    title character varying(255) NOT NULL,
    content text NOT NULL,
    author character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.articles OWNER TO theunitribe_admin;

--
-- Name: articles_id_seq; Type: SEQUENCE; Schema: public; Owner: theunitribe_admin
--

CREATE SEQUENCE public.articles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.articles_id_seq OWNER TO theunitribe_admin;

--
-- Name: articles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: theunitribe_admin
--

ALTER SEQUENCE public.articles_id_seq OWNED BY public.articles.id;


--
-- Name: blog_posts; Type: TABLE; Schema: public; Owner: theunitribe_admin
--

CREATE TABLE public.blog_posts (
    id bigint NOT NULL,
    title character varying(255) NOT NULL,
    content text NOT NULL,
    author character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.blog_posts OWNER TO theunitribe_admin;

--
-- Name: blog_posts_id_seq; Type: SEQUENCE; Schema: public; Owner: theunitribe_admin
--

CREATE SEQUENCE public.blog_posts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.blog_posts_id_seq OWNER TO theunitribe_admin;

--
-- Name: blog_posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: theunitribe_admin
--

ALTER SEQUENCE public.blog_posts_id_seq OWNED BY public.blog_posts.id;


--
-- Name: cache; Type: TABLE; Schema: public; Owner: theunitribe_admin
--

CREATE TABLE public.cache (
    key character varying(255) NOT NULL,
    value text NOT NULL,
    expiration integer NOT NULL
);


ALTER TABLE public.cache OWNER TO theunitribe_admin;

--
-- Name: cache_locks; Type: TABLE; Schema: public; Owner: theunitribe_admin
--

CREATE TABLE public.cache_locks (
    key character varying(255) NOT NULL,
    owner character varying(255) NOT NULL,
    expiration integer NOT NULL
);


ALTER TABLE public.cache_locks OWNER TO theunitribe_admin;

--
-- Name: cities; Type: TABLE; Schema: public; Owner: theunitribe_admin
--

CREATE TABLE public.cities (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    region_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.cities OWNER TO theunitribe_admin;

--
-- Name: cities_id_seq; Type: SEQUENCE; Schema: public; Owner: theunitribe_admin
--

CREATE SEQUENCE public.cities_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cities_id_seq OWNER TO theunitribe_admin;

--
-- Name: cities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: theunitribe_admin
--

ALTER SEQUENCE public.cities_id_seq OWNED BY public.cities.id;


--
-- Name: countries; Type: TABLE; Schema: public; Owner: theunitribe_admin
--

CREATE TABLE public.countries (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.countries OWNER TO theunitribe_admin;

--
-- Name: countries_id_seq; Type: SEQUENCE; Schema: public; Owner: theunitribe_admin
--

CREATE SEQUENCE public.countries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.countries_id_seq OWNER TO theunitribe_admin;

--
-- Name: countries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: theunitribe_admin
--

ALTER SEQUENCE public.countries_id_seq OWNED BY public.countries.id;


--
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: theunitribe_admin
--

CREATE TABLE public.failed_jobs (
    id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    connection text NOT NULL,
    queue text NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.failed_jobs OWNER TO theunitribe_admin;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: theunitribe_admin
--

CREATE SEQUENCE public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.failed_jobs_id_seq OWNER TO theunitribe_admin;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: theunitribe_admin
--

ALTER SEQUENCE public.failed_jobs_id_seq OWNED BY public.failed_jobs.id;


--
-- Name: follows; Type: TABLE; Schema: public; Owner: theunitribe_admin
--

CREATE TABLE public.follows (
    id bigint NOT NULL,
    follower_id bigint NOT NULL,
    followed_id bigint NOT NULL,
    is_accepted boolean DEFAULT true NOT NULL,
    blocked_at timestamp(0) without time zone,
    visibility character varying(255) DEFAULT 'public'::character varying NOT NULL,
    is_muted boolean DEFAULT false NOT NULL,
    notifications_enabled boolean DEFAULT true NOT NULL,
    source character varying(50),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT follows_visibility_check CHECK (((visibility)::text = ANY ((ARRAY['public'::character varying, 'friends_only'::character varying])::text[])))
);


ALTER TABLE public.follows OWNER TO theunitribe_admin;

--
-- Name: follows_id_seq; Type: SEQUENCE; Schema: public; Owner: theunitribe_admin
--

CREATE SEQUENCE public.follows_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.follows_id_seq OWNER TO theunitribe_admin;

--
-- Name: follows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: theunitribe_admin
--

ALTER SEQUENCE public.follows_id_seq OWNED BY public.follows.id;


--
-- Name: forums; Type: TABLE; Schema: public; Owner: theunitribe_admin
--

CREATE TABLE public.forums (
    id bigint NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    category character varying(255) DEFAULT 'general'::character varying NOT NULL,
    comments integer DEFAULT 0 NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.forums OWNER TO theunitribe_admin;

--
-- Name: forums_id_seq; Type: SEQUENCE; Schema: public; Owner: theunitribe_admin
--

CREATE SEQUENCE public.forums_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.forums_id_seq OWNER TO theunitribe_admin;

--
-- Name: forums_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: theunitribe_admin
--

ALTER SEQUENCE public.forums_id_seq OWNED BY public.forums.id;


--
-- Name: job_batches; Type: TABLE; Schema: public; Owner: theunitribe_admin
--

CREATE TABLE public.job_batches (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    total_jobs integer NOT NULL,
    pending_jobs integer NOT NULL,
    failed_jobs integer NOT NULL,
    failed_job_ids text NOT NULL,
    options text,
    cancelled_at integer,
    created_at integer NOT NULL,
    finished_at integer
);


ALTER TABLE public.job_batches OWNER TO theunitribe_admin;

--
-- Name: jobs; Type: TABLE; Schema: public; Owner: theunitribe_admin
--

CREATE TABLE public.jobs (
    id bigint NOT NULL,
    queue character varying(255) NOT NULL,
    payload text NOT NULL,
    attempts smallint NOT NULL,
    reserved_at integer,
    available_at integer NOT NULL,
    created_at integer NOT NULL
);


ALTER TABLE public.jobs OWNER TO theunitribe_admin;

--
-- Name: jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: theunitribe_admin
--

CREATE SEQUENCE public.jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.jobs_id_seq OWNER TO theunitribe_admin;

--
-- Name: jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: theunitribe_admin
--

ALTER SEQUENCE public.jobs_id_seq OWNED BY public.jobs.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: theunitribe_admin
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE public.migrations OWNER TO theunitribe_admin;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: theunitribe_admin
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.migrations_id_seq OWNER TO theunitribe_admin;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: theunitribe_admin
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: model_has_permissions; Type: TABLE; Schema: public; Owner: theunitribe_admin
--

CREATE TABLE public.model_has_permissions (
    permission_id bigint NOT NULL,
    model_type character varying(255) NOT NULL,
    model_id bigint NOT NULL
);


ALTER TABLE public.model_has_permissions OWNER TO theunitribe_admin;

--
-- Name: model_has_roles; Type: TABLE; Schema: public; Owner: theunitribe_admin
--

CREATE TABLE public.model_has_roles (
    role_id bigint NOT NULL,
    model_type character varying(255) NOT NULL,
    model_id bigint NOT NULL
);


ALTER TABLE public.model_has_roles OWNER TO theunitribe_admin;

--
-- Name: network_user; Type: TABLE; Schema: public; Owner: theunitribe_admin
--

CREATE TABLE public.network_user (
    id bigint NOT NULL,
    network_id bigint NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.network_user OWNER TO theunitribe_admin;

--
-- Name: network_user_id_seq; Type: SEQUENCE; Schema: public; Owner: theunitribe_admin
--

CREATE SEQUENCE public.network_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.network_user_id_seq OWNER TO theunitribe_admin;

--
-- Name: network_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: theunitribe_admin
--

ALTER SEQUENCE public.network_user_id_seq OWNED BY public.network_user.id;


--
-- Name: networks; Type: TABLE; Schema: public; Owner: theunitribe_admin
--

CREATE TABLE public.networks (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text,
    is_public boolean DEFAULT false NOT NULL,
    access_level character varying(255) DEFAULT 'open'::character varying NOT NULL,
    cover_image character varying(255),
    color_theme character varying(255) DEFAULT '#3498db'::character varying NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.networks OWNER TO theunitribe_admin;

--
-- Name: COLUMN networks.access_level; Type: COMMENT; Schema: public; Owner: theunitribe_admin
--

COMMENT ON COLUMN public.networks.access_level IS 'open, approval, invite-only';


--
-- Name: networks_id_seq; Type: SEQUENCE; Schema: public; Owner: theunitribe_admin
--

CREATE SEQUENCE public.networks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.networks_id_seq OWNER TO theunitribe_admin;

--
-- Name: networks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: theunitribe_admin
--

ALTER SEQUENCE public.networks_id_seq OWNED BY public.networks.id;


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: theunitribe_admin
--

CREATE TABLE public.permissions (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    guard_name character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.permissions OWNER TO theunitribe_admin;

--
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: theunitribe_admin
--

CREATE SEQUENCE public.permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.permissions_id_seq OWNER TO theunitribe_admin;

--
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: theunitribe_admin
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- Name: pincodes; Type: TABLE; Schema: public; Owner: theunitribe_admin
--

CREATE TABLE public.pincodes (
    id bigint NOT NULL,
    pincode character varying(255) NOT NULL,
    city_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.pincodes OWNER TO theunitribe_admin;

--
-- Name: pincodes_id_seq; Type: SEQUENCE; Schema: public; Owner: theunitribe_admin
--

CREATE SEQUENCE public.pincodes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pincodes_id_seq OWNER TO theunitribe_admin;

--
-- Name: pincodes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: theunitribe_admin
--

ALTER SEQUENCE public.pincodes_id_seq OWNED BY public.pincodes.id;


--
-- Name: regions; Type: TABLE; Schema: public; Owner: theunitribe_admin
--

CREATE TABLE public.regions (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    country_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.regions OWNER TO theunitribe_admin;

--
-- Name: regions_id_seq; Type: SEQUENCE; Schema: public; Owner: theunitribe_admin
--

CREATE SEQUENCE public.regions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.regions_id_seq OWNER TO theunitribe_admin;

--
-- Name: regions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: theunitribe_admin
--

ALTER SEQUENCE public.regions_id_seq OWNED BY public.regions.id;


--
-- Name: reputation_categories; Type: TABLE; Schema: public; Owner: theunitribe_admin
--

CREATE TABLE public.reputation_categories (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.reputation_categories OWNER TO theunitribe_admin;

--
-- Name: reputation_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: theunitribe_admin
--

CREATE SEQUENCE public.reputation_categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.reputation_categories_id_seq OWNER TO theunitribe_admin;

--
-- Name: reputation_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: theunitribe_admin
--

ALTER SEQUENCE public.reputation_categories_id_seq OWNED BY public.reputation_categories.id;


--
-- Name: role_has_permissions; Type: TABLE; Schema: public; Owner: theunitribe_admin
--

CREATE TABLE public.role_has_permissions (
    permission_id bigint NOT NULL,
    role_id bigint NOT NULL
);


ALTER TABLE public.role_has_permissions OWNER TO theunitribe_admin;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: theunitribe_admin
--

CREATE TABLE public.roles (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    guard_name character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.roles OWNER TO theunitribe_admin;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: theunitribe_admin
--

CREATE SEQUENCE public.roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.roles_id_seq OWNER TO theunitribe_admin;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: theunitribe_admin
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: theunitribe_admin
--

CREATE TABLE public.sessions (
    id character varying(255) NOT NULL,
    user_id bigint,
    ip_address character varying(45),
    user_agent text,
    payload text NOT NULL,
    last_activity integer NOT NULL
);


ALTER TABLE public.sessions OWNER TO theunitribe_admin;

--
-- Name: user_contacts; Type: TABLE; Schema: public; Owner: theunitribe_admin
--

CREATE TABLE public.user_contacts (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    type character varying(255) NOT NULL,
    value character varying(255) NOT NULL,
    is_public boolean DEFAULT false NOT NULL,
    verified_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT user_contacts_type_check CHECK (((type)::text = ANY ((ARRAY['phone'::character varying, 'email'::character varying, 'telegram'::character varying, 'whatsapp'::character varying, 'signal'::character varying, 'discord'::character varying])::text[])))
);


ALTER TABLE public.user_contacts OWNER TO theunitribe_admin;

--
-- Name: user_contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: theunitribe_admin
--

CREATE SEQUENCE public.user_contacts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_contacts_id_seq OWNER TO theunitribe_admin;

--
-- Name: user_contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: theunitribe_admin
--

ALTER SEQUENCE public.user_contacts_id_seq OWNED BY public.user_contacts.id;


--
-- Name: user_educations; Type: TABLE; Schema: public; Owner: theunitribe_admin
--

CREATE TABLE public.user_educations (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    institution character varying(255) NOT NULL,
    degree character varying(255),
    specialization character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    start_date date,
    end_date date
);


ALTER TABLE public.user_educations OWNER TO theunitribe_admin;

--
-- Name: user_educations_id_seq; Type: SEQUENCE; Schema: public; Owner: theunitribe_admin
--

CREATE SEQUENCE public.user_educations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_educations_id_seq OWNER TO theunitribe_admin;

--
-- Name: user_educations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: theunitribe_admin
--

ALTER SEQUENCE public.user_educations_id_seq OWNED BY public.user_educations.id;


--
-- Name: user_experiences; Type: TABLE; Schema: public; Owner: theunitribe_admin
--

CREATE TABLE public.user_experiences (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    title character varying(100) NOT NULL,
    company character varying(255) NOT NULL,
    location character varying(255),
    start_date date NOT NULL,
    end_date date,
    description text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.user_experiences OWNER TO theunitribe_admin;

--
-- Name: user_experiences_id_seq; Type: SEQUENCE; Schema: public; Owner: theunitribe_admin
--

CREATE SEQUENCE public.user_experiences_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_experiences_id_seq OWNER TO theunitribe_admin;

--
-- Name: user_experiences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: theunitribe_admin
--

ALTER SEQUENCE public.user_experiences_id_seq OWNED BY public.user_experiences.id;


--
-- Name: user_links; Type: TABLE; Schema: public; Owner: theunitribe_admin
--

CREATE TABLE public.user_links (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    platform character varying(255) NOT NULL,
    url character varying(512) NOT NULL,
    label character varying(255),
    is_public boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT user_links_platform_check CHECK (((platform)::text = ANY ((ARRAY['twitter'::character varying, 'linkedin'::character varying, 'instagram'::character varying, 'facebook'::character varying, 'youtube'::character varying, 'tiktok'::character varying, 'github'::character varying, 'website'::character varying, 'custom'::character varying])::text[])))
);


ALTER TABLE public.user_links OWNER TO theunitribe_admin;

--
-- Name: user_links_id_seq; Type: SEQUENCE; Schema: public; Owner: theunitribe_admin
--

CREATE SEQUENCE public.user_links_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_links_id_seq OWNER TO theunitribe_admin;

--
-- Name: user_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: theunitribe_admin
--

ALTER SEQUENCE public.user_links_id_seq OWNED BY public.user_links.id;


--
-- Name: user_settings; Type: TABLE; Schema: public; Owner: theunitribe_admin
--

CREATE TABLE public.user_settings (
    user_id bigint NOT NULL,
    who_can_see_birthdate character varying(255) DEFAULT 'nobody'::character varying NOT NULL,
    who_can_message_you character varying(255) DEFAULT 'followers'::character varying NOT NULL,
    email_notifications boolean DEFAULT true NOT NULL,
    push_notifications boolean DEFAULT true NOT NULL,
    dark_mode boolean DEFAULT false NOT NULL,
    language character varying(10) DEFAULT 'en'::character varying NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT user_settings_who_can_message_you_check CHECK (((who_can_message_you)::text = ANY ((ARRAY['everyone'::character varying, 'followers'::character varying, 'nobody'::character varying])::text[]))),
    CONSTRAINT user_settings_who_can_see_birthdate_check CHECK (((who_can_see_birthdate)::text = ANY ((ARRAY['public'::character varying, 'followers'::character varying, 'nobody'::character varying])::text[])))
);


ALTER TABLE public.user_settings OWNER TO theunitribe_admin;

--
-- Name: user_skills; Type: TABLE; Schema: public; Owner: theunitribe_admin
--

CREATE TABLE public.user_skills (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    name character varying(100) NOT NULL,
    category character varying(50),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.user_skills OWNER TO theunitribe_admin;

--
-- Name: user_skills_id_seq; Type: SEQUENCE; Schema: public; Owner: theunitribe_admin
--

CREATE SEQUENCE public.user_skills_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_skills_id_seq OWNER TO theunitribe_admin;

--
-- Name: user_skills_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: theunitribe_admin
--

ALTER SEQUENCE public.user_skills_id_seq OWNED BY public.user_skills.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: theunitribe_admin
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    username character varying(100) NOT NULL,
    email character varying(255) NOT NULL,
    password character varying(255),
    is_active timestamp(0) without time zone,
    is_verified timestamp(0) without time zone,
    email_verified_at timestamp(0) without time zone,
    password_reset_token character varying(255),
    password_reset_expires timestamp(0) without time zone,
    two_factor_secret character varying(255),
    two_factor_enabled boolean DEFAULT false NOT NULL,
    account_type character varying(20) DEFAULT 'basic'::character varying NOT NULL,
    location character varying(50),
    first_name character varying(100),
    last_name character varying(100),
    title character varying(255),
    date_of_birth date,
    gender character varying(255),
    phone character varying(20),
    profile_pic character varying(255),
    bio text,
    about text,
    website_url character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    remember_token character varying(100),
    provider character varying(255),
    provider_id character varying(255),
    avatar character varying(255),
    CONSTRAINT users_gender_check CHECK (((gender)::text = ANY ((ARRAY['male'::character varying, 'female'::character varying, 'other'::character varying, 'prefer_not_to_say'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO theunitribe_admin;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: theunitribe_admin
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO theunitribe_admin;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: theunitribe_admin
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: articles id; Type: DEFAULT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.articles ALTER COLUMN id SET DEFAULT nextval('public.articles_id_seq'::regclass);


--
-- Name: blog_posts id; Type: DEFAULT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.blog_posts ALTER COLUMN id SET DEFAULT nextval('public.blog_posts_id_seq'::regclass);


--
-- Name: cities id; Type: DEFAULT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.cities ALTER COLUMN id SET DEFAULT nextval('public.cities_id_seq'::regclass);


--
-- Name: countries id; Type: DEFAULT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.countries ALTER COLUMN id SET DEFAULT nextval('public.countries_id_seq'::regclass);


--
-- Name: failed_jobs id; Type: DEFAULT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.failed_jobs ALTER COLUMN id SET DEFAULT nextval('public.failed_jobs_id_seq'::regclass);


--
-- Name: follows id; Type: DEFAULT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.follows ALTER COLUMN id SET DEFAULT nextval('public.follows_id_seq'::regclass);


--
-- Name: forums id; Type: DEFAULT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.forums ALTER COLUMN id SET DEFAULT nextval('public.forums_id_seq'::regclass);


--
-- Name: jobs id; Type: DEFAULT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.jobs ALTER COLUMN id SET DEFAULT nextval('public.jobs_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: network_user id; Type: DEFAULT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.network_user ALTER COLUMN id SET DEFAULT nextval('public.network_user_id_seq'::regclass);


--
-- Name: networks id; Type: DEFAULT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.networks ALTER COLUMN id SET DEFAULT nextval('public.networks_id_seq'::regclass);


--
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- Name: pincodes id; Type: DEFAULT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.pincodes ALTER COLUMN id SET DEFAULT nextval('public.pincodes_id_seq'::regclass);


--
-- Name: regions id; Type: DEFAULT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.regions ALTER COLUMN id SET DEFAULT nextval('public.regions_id_seq'::regclass);


--
-- Name: reputation_categories id; Type: DEFAULT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.reputation_categories ALTER COLUMN id SET DEFAULT nextval('public.reputation_categories_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: user_contacts id; Type: DEFAULT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.user_contacts ALTER COLUMN id SET DEFAULT nextval('public.user_contacts_id_seq'::regclass);


--
-- Name: user_educations id; Type: DEFAULT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.user_educations ALTER COLUMN id SET DEFAULT nextval('public.user_educations_id_seq'::regclass);


--
-- Name: user_experiences id; Type: DEFAULT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.user_experiences ALTER COLUMN id SET DEFAULT nextval('public.user_experiences_id_seq'::regclass);


--
-- Name: user_links id; Type: DEFAULT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.user_links ALTER COLUMN id SET DEFAULT nextval('public.user_links_id_seq'::regclass);


--
-- Name: user_skills id; Type: DEFAULT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.user_skills ALTER COLUMN id SET DEFAULT nextval('public.user_skills_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: articles; Type: TABLE DATA; Schema: public; Owner: theunitribe_admin
--

COPY public.articles (id, title, content, author, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: blog_posts; Type: TABLE DATA; Schema: public; Owner: theunitribe_admin
--

COPY public.blog_posts (id, title, content, author, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: cache; Type: TABLE DATA; Schema: public; Owner: theunitribe_admin
--

COPY public.cache (key, value, expiration) FROM stdin;
\.


--
-- Data for Name: cache_locks; Type: TABLE DATA; Schema: public; Owner: theunitribe_admin
--

COPY public.cache_locks (key, owner, expiration) FROM stdin;
\.


--
-- Data for Name: cities; Type: TABLE DATA; Schema: public; Owner: theunitribe_admin
--

COPY public.cities (id, name, region_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: countries; Type: TABLE DATA; Schema: public; Owner: theunitribe_admin
--

COPY public.countries (id, name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: theunitribe_admin
--

COPY public.failed_jobs (id, uuid, connection, queue, payload, exception, failed_at) FROM stdin;
\.


--
-- Data for Name: follows; Type: TABLE DATA; Schema: public; Owner: theunitribe_admin
--

COPY public.follows (id, follower_id, followed_id, is_accepted, blocked_at, visibility, is_muted, notifications_enabled, source, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: forums; Type: TABLE DATA; Schema: public; Owner: theunitribe_admin
--

COPY public.forums (id, title, description, category, comments, user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: job_batches; Type: TABLE DATA; Schema: public; Owner: theunitribe_admin
--

COPY public.job_batches (id, name, total_jobs, pending_jobs, failed_jobs, failed_job_ids, options, cancelled_at, created_at, finished_at) FROM stdin;
\.


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: theunitribe_admin
--

COPY public.jobs (id, queue, payload, attempts, reserved_at, available_at, created_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: theunitribe_admin
--

COPY public.migrations (id, migration, batch) FROM stdin;
92	0001_01_01_000000_create_users_table	2
93	0001_01_01_000001_create_cache_table	2
94	0001_01_01_000002_create_jobs_table	2
95	2024_06_01_000000_create_permission_tables	2
96	2024_06_15_000001_create_forums_table	2
97	2024_06_15_000002_create_blog_posts_table	2
98	2024_06_15_000003_create_articles_table	2
99	2024_07_01_000001_create_networks_table	2
100	2024_07_01_000002_create_network_user_table	2
101	2025_01_15_000000_add_social_login_fields_to_users_table	2
102	2025_07_09_090634_create_countries_table	2
103	2025_07_09_090657_create_cities_table	2
104	2025_07_09_090718_create_regions_table	2
105	2025_07_10_000000_create_pincodes_table	2
106	2025_10_16_022915_create_user_settings_table	2
107	2025_10_16_022916_create_user_educations_table	2
108	2025_10_16_022916_create_user_experiences_table	2
109	2025_10_16_022916_create_user_links_table	2
110	2025_10_16_022917_create_user_contacts_table	2
111	2025_10_16_022917_create_user_skills_table	2
112	2025_10_16_041026_create_sessions_table	2
113	2025_11_06_012128_create_follows_table	2
114	2025_11_06_060542_create_reputation_categories_table	2
115	2025_11_17_033824_update_user_educations_table_change_years_to_dates	2
90	2025_11_13_055935_add_description_to_user_experiences_table	1
\.


--
-- Data for Name: model_has_permissions; Type: TABLE DATA; Schema: public; Owner: theunitribe_admin
--

COPY public.model_has_permissions (permission_id, model_type, model_id) FROM stdin;
\.


--
-- Data for Name: model_has_roles; Type: TABLE DATA; Schema: public; Owner: theunitribe_admin
--

COPY public.model_has_roles (role_id, model_type, model_id) FROM stdin;
\.


--
-- Data for Name: network_user; Type: TABLE DATA; Schema: public; Owner: theunitribe_admin
--

COPY public.network_user (id, network_id, user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: networks; Type: TABLE DATA; Schema: public; Owner: theunitribe_admin
--

COPY public.networks (id, name, slug, description, is_public, access_level, cover_image, color_theme, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: theunitribe_admin
--

COPY public.permissions (id, name, guard_name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: pincodes; Type: TABLE DATA; Schema: public; Owner: theunitribe_admin
--

COPY public.pincodes (id, pincode, city_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: regions; Type: TABLE DATA; Schema: public; Owner: theunitribe_admin
--

COPY public.regions (id, name, country_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: reputation_categories; Type: TABLE DATA; Schema: public; Owner: theunitribe_admin
--

COPY public.reputation_categories (id, name, description, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: role_has_permissions; Type: TABLE DATA; Schema: public; Owner: theunitribe_admin
--

COPY public.role_has_permissions (permission_id, role_id) FROM stdin;
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: theunitribe_admin
--

COPY public.roles (id, name, guard_name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: theunitribe_admin
--

COPY public.sessions (id, user_id, ip_address, user_agent, payload, last_activity) FROM stdin;
ZFvazIfl7Fu9VgBB86aQaBQjYRGE02W8e3UOzdZc	\N	43.157.95.239	Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiUHhyOTVpRFpGS3N5YjJab1NTeDU3NXRQMnRDczlGejZqVmI0QnF1RCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vdGhldW5pdHJpYmUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1763440575
fVotc2lWglGRdvK5jExkMn2NRjGlyPUliYUqUq5k	1	203.81.240.237	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	YTo0OntzOjY6Il90b2tlbiI7czo0MDoic2NYWHJUQ3pIbjIxN3dZQmZweFVHZlJWVTBTWHhUazdFcjRMSXVCRyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjg6Imh0dHBzOi8vdGhldW5pdHJpYmUuY29tL2hvbWUiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7fQ==	1763441527
uEFx9JWY7woUxgHelkfQam1IghkttQJHzYlT44Rk	\N	185.242.226.105	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoib1dVV1hmOGg5cGZ6aUgzR0RHYWxKVHVDNEZMa0xCWjdUeWd3YVdtVCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vNzIuNjAuMTE2LjE0MSI7czo1OiJyb3V0ZSI7Tjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1763442591
gzT3PjtBhIM5Mc5a0aqhdvU0DFgKpv2DIkhn4HhH	\N	74.7.227.7	Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; GPTBot/1.3; +https://openai.com/gptbot)	YTozOntzOjY6Il90b2tlbiI7czo0MDoieFFFdmt6Zjl3YXAyNmpiQmVVZHlvRFk3QnlrQUJtenNZSkNVTFozWSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vd3d3LnRoZXVuaXRyaWJlLmNvbSI7czo1OiJyb3V0ZSI7Tjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1763449163
2OJ36zqIp7nizznaxFqBINBE8JDjbdIdWkgDkMNt	\N	79.110.53.14	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoib3U5WElqRWFsVXdVQWxUb1lzTDFTeVJvNERxelcyZkVBM2JFZ1poTCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vdGhldW5pdHJpYmUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1763452267
2hCk7ybVeE2XOqdx67V7tC1BjBEWOrLOPRsGXbVi	\N	185.170.167.18	Mozilla/5.0 (compatible; BacklinksExtendedBot)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSmV0VGVTRGVmeVhLd2lHSUxwR2s5MUJUbVcxeDNVZWdVYktJaERpdiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vdGhldW5pdHJpYmUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1763462802
QHt9zqVSgNTD1QeIGfG6vexSvhAlGmWijY5fW4Zr	\N	182.42.105.144	Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoia2dnSXFqNGtpTkFCS1lhSk96VmNTd0xOZmJZMVdiVzc4Q3NSaFR6YSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vd3d3LnRoZXVuaXRyaWJlLmNvbSI7czo1OiJyb3V0ZSI7Tjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1763464700
ponKwaymLNM7e1ZwSvKgN2ml7H05s8mzHv9i8rIr	\N	49.51.183.220	Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZlVzdXdiZG56SFpqTGp2bVRrQzNkMUowVUhZaFNEOG9ZeFFkZGhoUSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vd3d3LnRoZXVuaXRyaWJlLmNvbSI7czo1OiJyb3V0ZSI7Tjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1763472855
HZvJ3V45WGbawiXqaRcJzGKRZdHbjkVvjlFoC3Ev	\N	136.114.121.90	Mozilla/5.0 (compatible; CMS-Checker/1.0; +https://example.com)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiM3YxcmtHc1dXbkwzc1JLYk9LY0xmYjNGeHdOQThTZE91ZXZGRUpISiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vdGhldW5pdHJpYmUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1763472959
GcRHpBt7UtLAnlTSDou0fk40ZOFbEaeCqL0UilqY	\N	43.157.147.3	Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoid1hmemhnclNJYUJIWTJteXYwb2dOMlVQTWlvQ2lCaUd6RE8xbkVTcyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vdGhldW5pdHJpYmUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1763474260
w2b5RhVi2bwZCPUrZPvaq5jwY0C1rL6wupUZv8ck	\N	206.189.101.121	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiWWc3U0FBd29kYkFSRTJ3NjR0M0dkMXZZejFsM2sxeTdDVDc4em9ycSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vd3d3LnRoZXVuaXRyaWJlLmNvbSI7czo1OiJyb3V0ZSI7Tjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1763474271
FZ9cRSw7mwFvQiqaLf0ggVo9EiSswJmXCs1F4TWe	\N	106.219.121.221	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	YTo0OntzOjY6Il90b2tlbiI7czo0MDoiRWluQlBCVFZDZEY3dmdIR3pGeGhyQnRpaG5TM2RIRE9rc0dhQnY3ZiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDA6Imh0dHBzOi8vd3d3LnRoZXVuaXRyaWJlLmNvbS9sb2dpbi9nb29nbGUiO3M6NToicm91dGUiO3M6MTI6InNvY2lhbC5sb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NToic3RhdGUiO3M6NDA6IlZDZ0ZrOWFlVjFuQUxDZHdiWkhJUHNXenk0MTJyakNycjR3SkM0eHgiO30=	1763474775
zgpMt4ExbCzYB4D2jfOaxqAdwsnkK5Nx6DTBgLMf	1	106.219.121.221	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	YTo0OntzOjY6Il90b2tlbiI7czo0MDoieGFiTFVqdUFMeDVsNkh3TjVUZmZxUHI5dVVFZGp1UDViT0NBZ0ZrZyI7czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6MTtzOjY6Il9mbGFzaCI7YToyOntzOjM6Im5ldyI7YTowOnt9czozOiJvbGQiO2E6MDp7fX1zOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czoyODoiaHR0cHM6Ly90aGV1bml0cmliZS5jb20vaG9tZSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9fQ==	1763474803
bdbUr7hcWqRSLy4yi41A68QpDXekuxtzK4ntGiJM	\N	34.239.45.122	Mozilla/5.0 (iPad; U; CPU OS 4_3 like Mac OS X; en-us) AppleWebKit/533.17.9 (KHTML, like Gecko) Version/5.0.2 Mobile/8F190 Safari/6533.18.5	YTozOntzOjY6Il90b2tlbiI7czo0MDoiTElFT3Zzck5BbE5oUmlKZm5VU3V0TU5CQTBack5EV3piNVBjNjlWViI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vdGhldW5pdHJpYmUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1763482014
068YalRvW8KbZJZ43SJzOs2eJFiSEdhbY0EmNF4e	\N	66.132.153.122	Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVk9WYXRuN2FaamlmeGUzRWZSTU9vWkI5ZGNJbHBXeDloUDV2eHlDeCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vNzIuNjAuMTE2LjE0MSI7czo1OiJyb3V0ZSI7Tjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1763482296
DFdVh87urbVTRM3FknPkQHfn2QgA8sJxcPL0yK3j	\N	69.10.48.159	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiV1BORjBnTDNRODRCVGhSdzR4bE5JUTA3dkJOODdxZ21MTkE0ZTJERCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHBzOi8vdGhldW5pdHJpYmUuY29tIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1763485016
aUEjipRTEJQ7ltwHoB0YbSwxNAKvawjYBKD1TtA5	\N	124.221.217.82	Mozilla/5.0 (Linux; Android 10; LIO-AN00 Build/HUAWEILIO-AN00; wv) MicroMessenger Weixin QQ AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/78.0.3904.62 XWEB/2692 MMWEBSDK/200901 Mobile Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVFZ5MWh6bzZIM1FZYTYySDBDTVRWR0psUHFDVUtJUWJGT1VEWjhOMiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vNzIuNjAuMTE2LjE0MSI7czo1OiJyb3V0ZSI7Tjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1763485319
aV5bePwnZChPQSjPRB72cxjqSit318axlDIrCc7E	\N	34.16.98.131	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.6478.20 Safari/537.36	YToyOntzOjY6Il90b2tlbiI7czo0MDoiM2N6S2pWY1hOU0RpTGdTNThOMXZjcklBVFRkdDNLZm54M1pYTW9OVyI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1763493194
9fB5hBhx32FSJogxZEf0ToozMugF0432IF17DAwB	\N	34.16.98.131	Mozilla/5.0 (Macintosh; Intel Mac OS X 14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.6422.60 Safari/537.36 Edg/125.0.2535.51	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVldxNjV1UGxIdmdiU3Rla0ZTMjU1b1hiZnBoOExaSDlWdFhLelR6MCI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czoyODoiaHR0cDovL3RoZXVuaXRyaWJlLmNvbS9ibG9nLyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1763493194
l0K1TOlKN8Il3He4oZUnsrIqAlmMpLjNcMm2sL8U	\N	51.68.236.71	Mozilla/5.0 (compatible; MJ12bot/v2.0.4; http://mj12bot.com/)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiTFJ2aENSb3lYVW43UDRpWkJJUGxtNDNHT20wa1RoYWZjaGF1YTU0MSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vd3d3LnRoZXVuaXRyaWJlLmNvbSI7czo1OiJyb3V0ZSI7Tjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1763504318
3OckXuu3ITn0poDXv8F5oJSdWZg3LkbOAjbAL4iY	\N	194.187.176.29	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoic2tVaEdoSUNsd2FyS3dpU3hSeWY5czFCUThkcDFDYkdEWEI1UG5NZyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vNzIuNjAuMTE2LjE0MSI7czo1OiJyb3V0ZSI7Tjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1763511387
\.


--
-- Data for Name: user_contacts; Type: TABLE DATA; Schema: public; Owner: theunitribe_admin
--

COPY public.user_contacts (id, user_id, type, value, is_public, verified_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_educations; Type: TABLE DATA; Schema: public; Owner: theunitribe_admin
--

COPY public.user_educations (id, user_id, institution, degree, specialization, created_at, updated_at, start_date, end_date) FROM stdin;
1	1	UOC	BSC	SCi	2025-11-18 04:48:41	2025-11-18 04:48:41	2025-11-07	\N
\.


--
-- Data for Name: user_experiences; Type: TABLE DATA; Schema: public; Owner: theunitribe_admin
--

COPY public.user_experiences (id, user_id, title, company, location, start_date, end_date, description, created_at, updated_at) FROM stdin;
1	1	SFE	My Commpnay	Delhi India	2025-11-01	2025-11-17	<p>fasdfdsdsfsfssdfdsf</p>	2025-11-18 04:48:16	2025-11-18 04:48:16
\.


--
-- Data for Name: user_links; Type: TABLE DATA; Schema: public; Owner: theunitribe_admin
--

COPY public.user_links (id, user_id, platform, url, label, is_public, created_at, updated_at) FROM stdin;
8	1	custom	https://theunitribe.com/home		t	2025-11-18 14:06:43	2025-11-18 14:06:43
9	1	github	https://theunitribe.com/home	github	t	2025-11-18 14:06:43	2025-11-18 14:06:43
10	1	instagram	https://theunitribe.com/home	instagram	t	2025-11-18 14:06:43	2025-11-18 14:06:43
11	1	tiktok	https://theunitribe.com/home	tiktok	t	2025-11-18 14:06:43	2025-11-18 14:06:43
\.


--
-- Data for Name: user_settings; Type: TABLE DATA; Schema: public; Owner: theunitribe_admin
--

COPY public.user_settings (user_id, who_can_see_birthdate, who_can_message_you, email_notifications, push_notifications, dark_mode, language, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_skills; Type: TABLE DATA; Schema: public; Owner: theunitribe_admin
--

COPY public.user_skills (id, user_id, name, category, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: theunitribe_admin
--

COPY public.users (id, username, email, password, is_active, is_verified, email_verified_at, password_reset_token, password_reset_expires, two_factor_secret, two_factor_enabled, account_type, location, first_name, last_name, title, date_of_birth, gender, phone, profile_pic, bio, about, website_url, created_at, updated_at, remember_token, provider, provider_id, avatar) FROM stdin;
1	pro-coddy	procoddy25@gmail.com	$2y$12$t.8WldRH8iZ4oXDRMxXHo.13EztT/PTqkyOulXUjbNu9BsgczsGjS	\N	\N	\N	\N	\N	\N	f	basic	New Delhi India	Proi	Coddy	Manager	2025-11-01	male	9871421370	\N	Short Bio .......	<p><strong><em><u>l;kfl;f;laklasfl;;asf;lsdfl;sadl;adsl;fmlds;f;ldsfl;ds;lfmdsl;</u></em></strong></p>	https://theunitribe.com/home	2025-11-18 04:33:38	2025-11-18 04:51:02	fyX3ECkHoLEGGgdT7viE4L4HGLdSUU9KTivos0jqSgeX0G7BKHYrgl95lpFK	\N	\N	\N
\.


--
-- Name: articles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: theunitribe_admin
--

SELECT pg_catalog.setval('public.articles_id_seq', 1, false);


--
-- Name: blog_posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: theunitribe_admin
--

SELECT pg_catalog.setval('public.blog_posts_id_seq', 1, false);


--
-- Name: cities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: theunitribe_admin
--

SELECT pg_catalog.setval('public.cities_id_seq', 1, false);


--
-- Name: countries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: theunitribe_admin
--

SELECT pg_catalog.setval('public.countries_id_seq', 1, false);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: theunitribe_admin
--

SELECT pg_catalog.setval('public.failed_jobs_id_seq', 1, false);


--
-- Name: follows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: theunitribe_admin
--

SELECT pg_catalog.setval('public.follows_id_seq', 1, false);


--
-- Name: forums_id_seq; Type: SEQUENCE SET; Schema: public; Owner: theunitribe_admin
--

SELECT pg_catalog.setval('public.forums_id_seq', 1, false);


--
-- Name: jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: theunitribe_admin
--

SELECT pg_catalog.setval('public.jobs_id_seq', 1, false);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: theunitribe_admin
--

SELECT pg_catalog.setval('public.migrations_id_seq', 115, true);


--
-- Name: network_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: theunitribe_admin
--

SELECT pg_catalog.setval('public.network_user_id_seq', 1, false);


--
-- Name: networks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: theunitribe_admin
--

SELECT pg_catalog.setval('public.networks_id_seq', 1, false);


--
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: theunitribe_admin
--

SELECT pg_catalog.setval('public.permissions_id_seq', 1, false);


--
-- Name: pincodes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: theunitribe_admin
--

SELECT pg_catalog.setval('public.pincodes_id_seq', 1, false);


--
-- Name: regions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: theunitribe_admin
--

SELECT pg_catalog.setval('public.regions_id_seq', 1, false);


--
-- Name: reputation_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: theunitribe_admin
--

SELECT pg_catalog.setval('public.reputation_categories_id_seq', 1, false);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: theunitribe_admin
--

SELECT pg_catalog.setval('public.roles_id_seq', 1, false);


--
-- Name: user_contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: theunitribe_admin
--

SELECT pg_catalog.setval('public.user_contacts_id_seq', 1, false);


--
-- Name: user_educations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: theunitribe_admin
--

SELECT pg_catalog.setval('public.user_educations_id_seq', 1, true);


--
-- Name: user_experiences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: theunitribe_admin
--

SELECT pg_catalog.setval('public.user_experiences_id_seq', 1, true);


--
-- Name: user_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: theunitribe_admin
--

SELECT pg_catalog.setval('public.user_links_id_seq', 11, true);


--
-- Name: user_skills_id_seq; Type: SEQUENCE SET; Schema: public; Owner: theunitribe_admin
--

SELECT pg_catalog.setval('public.user_skills_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: theunitribe_admin
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: articles articles_pkey; Type: CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_pkey PRIMARY KEY (id);


--
-- Name: blog_posts blog_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.blog_posts
    ADD CONSTRAINT blog_posts_pkey PRIMARY KEY (id);


--
-- Name: cache_locks cache_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.cache_locks
    ADD CONSTRAINT cache_locks_pkey PRIMARY KEY (key);


--
-- Name: cache cache_pkey; Type: CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.cache
    ADD CONSTRAINT cache_pkey PRIMARY KEY (key);


--
-- Name: cities cities_pkey; Type: CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.cities
    ADD CONSTRAINT cities_pkey PRIMARY KEY (id);


--
-- Name: countries countries_pkey; Type: CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_uuid_unique UNIQUE (uuid);


--
-- Name: follows follows_pkey; Type: CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.follows
    ADD CONSTRAINT follows_pkey PRIMARY KEY (id);


--
-- Name: follows follows_unique_follower_followed; Type: CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.follows
    ADD CONSTRAINT follows_unique_follower_followed UNIQUE (follower_id, followed_id);


--
-- Name: forums forums_pkey; Type: CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.forums
    ADD CONSTRAINT forums_pkey PRIMARY KEY (id);


--
-- Name: job_batches job_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.job_batches
    ADD CONSTRAINT job_batches_pkey PRIMARY KEY (id);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: model_has_permissions model_has_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.model_has_permissions
    ADD CONSTRAINT model_has_permissions_pkey PRIMARY KEY (permission_id, model_id, model_type);


--
-- Name: model_has_roles model_has_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.model_has_roles
    ADD CONSTRAINT model_has_roles_pkey PRIMARY KEY (role_id, model_id, model_type);


--
-- Name: network_user network_user_network_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.network_user
    ADD CONSTRAINT network_user_network_id_user_id_unique UNIQUE (network_id, user_id);


--
-- Name: network_user network_user_pkey; Type: CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.network_user
    ADD CONSTRAINT network_user_pkey PRIMARY KEY (id);


--
-- Name: networks networks_name_unique; Type: CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.networks
    ADD CONSTRAINT networks_name_unique UNIQUE (name);


--
-- Name: networks networks_pkey; Type: CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.networks
    ADD CONSTRAINT networks_pkey PRIMARY KEY (id);


--
-- Name: networks networks_slug_unique; Type: CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.networks
    ADD CONSTRAINT networks_slug_unique UNIQUE (slug);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: pincodes pincodes_pkey; Type: CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.pincodes
    ADD CONSTRAINT pincodes_pkey PRIMARY KEY (id);


--
-- Name: regions regions_pkey; Type: CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.regions
    ADD CONSTRAINT regions_pkey PRIMARY KEY (id);


--
-- Name: reputation_categories reputation_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.reputation_categories
    ADD CONSTRAINT reputation_categories_pkey PRIMARY KEY (id);


--
-- Name: role_has_permissions role_has_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_pkey PRIMARY KEY (permission_id, role_id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: user_contacts user_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.user_contacts
    ADD CONSTRAINT user_contacts_pkey PRIMARY KEY (id);


--
-- Name: user_contacts user_contacts_user_id_type_unique; Type: CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.user_contacts
    ADD CONSTRAINT user_contacts_user_id_type_unique UNIQUE (user_id, type);


--
-- Name: user_educations user_educations_pkey; Type: CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.user_educations
    ADD CONSTRAINT user_educations_pkey PRIMARY KEY (id);


--
-- Name: user_experiences user_experiences_pkey; Type: CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.user_experiences
    ADD CONSTRAINT user_experiences_pkey PRIMARY KEY (id);


--
-- Name: user_links user_links_pkey; Type: CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.user_links
    ADD CONSTRAINT user_links_pkey PRIMARY KEY (id);


--
-- Name: user_links user_links_user_id_platform_unique; Type: CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.user_links
    ADD CONSTRAINT user_links_user_id_platform_unique UNIQUE (user_id, platform);


--
-- Name: user_settings user_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.user_settings
    ADD CONSTRAINT user_settings_pkey PRIMARY KEY (user_id);


--
-- Name: user_skills user_skills_pkey; Type: CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.user_skills
    ADD CONSTRAINT user_skills_pkey PRIMARY KEY (id);


--
-- Name: user_skills user_skills_user_id_name_unique; Type: CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.user_skills
    ADD CONSTRAINT user_skills_user_id_name_unique UNIQUE (user_id, name);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_unique; Type: CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_unique UNIQUE (username);


--
-- Name: idx_follows_blocked_at; Type: INDEX; Schema: public; Owner: theunitribe_admin
--

CREATE INDEX idx_follows_blocked_at ON public.follows USING btree (blocked_at);


--
-- Name: idx_follows_followed_created_at; Type: INDEX; Schema: public; Owner: theunitribe_admin
--

CREATE INDEX idx_follows_followed_created_at ON public.follows USING btree (followed_id, created_at);


--
-- Name: idx_follows_follower_created_at; Type: INDEX; Schema: public; Owner: theunitribe_admin
--

CREATE INDEX idx_follows_follower_created_at ON public.follows USING btree (follower_id, created_at);


--
-- Name: jobs_queue_index; Type: INDEX; Schema: public; Owner: theunitribe_admin
--

CREATE INDEX jobs_queue_index ON public.jobs USING btree (queue);


--
-- Name: model_has_permissions_model_id_model_type_index; Type: INDEX; Schema: public; Owner: theunitribe_admin
--

CREATE INDEX model_has_permissions_model_id_model_type_index ON public.model_has_permissions USING btree (model_id, model_type);


--
-- Name: model_has_roles_model_id_model_type_index; Type: INDEX; Schema: public; Owner: theunitribe_admin
--

CREATE INDEX model_has_roles_model_id_model_type_index ON public.model_has_roles USING btree (model_id, model_type);


--
-- Name: sessions_last_activity_index; Type: INDEX; Schema: public; Owner: theunitribe_admin
--

CREATE INDEX sessions_last_activity_index ON public.sessions USING btree (last_activity);


--
-- Name: sessions_user_id_index; Type: INDEX; Schema: public; Owner: theunitribe_admin
--

CREATE INDEX sessions_user_id_index ON public.sessions USING btree (user_id);


--
-- Name: user_educations_user_id_index; Type: INDEX; Schema: public; Owner: theunitribe_admin
--

CREATE INDEX user_educations_user_id_index ON public.user_educations USING btree (user_id);


--
-- Name: user_experiences_user_id_index; Type: INDEX; Schema: public; Owner: theunitribe_admin
--

CREATE INDEX user_experiences_user_id_index ON public.user_experiences USING btree (user_id);


--
-- Name: users_created_at_index; Type: INDEX; Schema: public; Owner: theunitribe_admin
--

CREATE INDEX users_created_at_index ON public.users USING btree (created_at);


--
-- Name: users_email_index; Type: INDEX; Schema: public; Owner: theunitribe_admin
--

CREATE INDEX users_email_index ON public.users USING btree (email);


--
-- Name: users_is_active_index; Type: INDEX; Schema: public; Owner: theunitribe_admin
--

CREATE INDEX users_is_active_index ON public.users USING btree (is_active);


--
-- Name: users_is_active_is_verified_index; Type: INDEX; Schema: public; Owner: theunitribe_admin
--

CREATE INDEX users_is_active_is_verified_index ON public.users USING btree (is_active, is_verified);


--
-- Name: users_username_index; Type: INDEX; Schema: public; Owner: theunitribe_admin
--

CREATE INDEX users_username_index ON public.users USING btree (username);


--
-- Name: follows follows_followed_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.follows
    ADD CONSTRAINT follows_followed_id_foreign FOREIGN KEY (followed_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: follows follows_follower_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.follows
    ADD CONSTRAINT follows_follower_id_foreign FOREIGN KEY (follower_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: forums forums_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.forums
    ADD CONSTRAINT forums_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: model_has_permissions model_has_permissions_permission_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.model_has_permissions
    ADD CONSTRAINT model_has_permissions_permission_id_foreign FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: model_has_roles model_has_roles_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.model_has_roles
    ADD CONSTRAINT model_has_roles_role_id_foreign FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: network_user network_user_network_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.network_user
    ADD CONSTRAINT network_user_network_id_foreign FOREIGN KEY (network_id) REFERENCES public.networks(id);


--
-- Name: network_user network_user_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.network_user
    ADD CONSTRAINT network_user_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: pincodes pincodes_city_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.pincodes
    ADD CONSTRAINT pincodes_city_id_foreign FOREIGN KEY (city_id) REFERENCES public.cities(id);


--
-- Name: regions regions_country_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.regions
    ADD CONSTRAINT regions_country_id_foreign FOREIGN KEY (country_id) REFERENCES public.countries(id);


--
-- Name: role_has_permissions role_has_permissions_permission_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_permission_id_foreign FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: role_has_permissions role_has_permissions_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_role_id_foreign FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: user_contacts user_contacts_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.user_contacts
    ADD CONSTRAINT user_contacts_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_educations user_educations_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.user_educations
    ADD CONSTRAINT user_educations_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_experiences user_experiences_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.user_experiences
    ADD CONSTRAINT user_experiences_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_links user_links_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.user_links
    ADD CONSTRAINT user_links_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_settings user_settings_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.user_settings
    ADD CONSTRAINT user_settings_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_skills user_skills_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: theunitribe_admin
--

ALTER TABLE ONLY public.user_skills
    ADD CONSTRAINT user_skills_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict fakDtu1XBfaBxq7cVQF5OXbnbbrzagaeBY31z0Le5emalcw2qnd1J2AjuF5gLVY

